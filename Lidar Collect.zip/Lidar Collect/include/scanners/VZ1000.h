#ifndef VZ1000_H
#define VZ1000_H

#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>

#include <riegl/ctrllib.hpp>
#include <riegl/scanlib.hpp>
#include <riegl/ridataspec.hpp>

#include "../globals.h"


namespace frf {

	/**
	 * @brief The VZ1000 class provides all functionality for the Riegl VZ1000
	 *
	 * Typical usage:
	 *  - Create instance of class, passing in ip address of scanner and
	 *    optionally a verbosity level
	 *  - Optionally set output directory
	 *  - Optionally log files using VZ1000::set_log_file_*()
	 *  - Do scanner stuff
	 *
	 */
	class VZ1000 {

		public:

			enum	VerboseLevel { SILENT=1, QUIET=2, VERBOSE=3, LOUD=4 };	// Levels of cmd-line verbosity
			enum	ScanType { NONE, LINE, FRAME, FRAMESEQ };				// Types of possible scans

			/** Constructors/Destructors **/
			VZ1000(std::string ip_address, VerboseLevel verbose_level = VERBOSE);
			~VZ1000();


			/** Member Functions **/
			// Scanner commands
			bool	connect();
			void	disconnect();
			void	start_scanning();
			void	wait_for_scanner();


			// Scan types
			std::string	framescan(int program, float theta_start, float theta_end, float theta_inc, float phi_start, float phi_end, float phi_inc, int num_seq=1);
			std::string	linescan(int program, float theta_start, float theta_end, float theta_inc, float phi, float duration_seconds);


			// Scanner exe commands without inputs
			std::string                 acknoledge_errors()     { return execute_command("ERRACK"); }
			std::string                 acknowledge_warnings()  { return execute_command("WARNACK"); }
			std::string                 abort_scanning()        { return execute_command("MEAS_ABORT"); }
			std::vector<std::string>    error_list()            { return execute_command_comments("ERR"); }
			std::string                 park()                  { return execute_command("SCN_PARK"); }
			std::string                 stop_scanning()         { return execute_command("MEAS_STOP"); }


			// Scanner exe commands with inputs
			std::string	inclination(std::string mode = "0");
			std::string	position_estimate(std::string mode = "0", std::string update_hdr = "0");


			// Scanner setters
			void	set_atmospheric_humidity(int percent_humidity);
			void	set_atmospheric_pressure_sl(int pressure_mbar);
			void	set_atmospheric_temperature(int degrees_c);
			void	set_camera_exposure_mode(int mode);
			void	set_camera_exposure_time(float seconds);
			void	set_camera_lens_aperture(float aperture);
			void	set_camera_white_balance_mode(int mode);
			void	set_gps_mode(int mode);
			void	set_gps_voltage(float voltage);
			void	set_near_range_enabled(bool is_enabled);
			void	set_reduced_quality_enabled(bool is_enabled);


			// Scanner getters
			std::string	atmospheric_humidity()         { return get_property("ATMOS_REL_HUMID"); }
			std::string	atmospheric_pressure()         { return get_property("ATMOS_PRESSURE"); }
			std::string	atmospheric_pressure_sl()      { return get_property("ATMOS_PRESSURE_SL"); }
			std::string	atmospheric_temperature()      { return get_property("ATMOS_TEMP"); }
			std::string	available_memory_internal()    { return get_property("STOR_MEM_AVAIL"); }
			std::string	battery_charge_state()         { return get_property("HK_CHARGE"); }
			std::string	battery_supply_voltage()       { return get_property("HK_U_IN_BAT"); }
			std::string	camera_exposure_mode()         { return get_property("CAM_EXPOSURE_MODE"); }
			std::string	camera_exposure_time()         { return get_property("CAM_EXPOSURE_TIME"); }
			std::string	camera_image_size()            { return get_property("CAM_IMG_SIZE"); }
			std::string	camera_lens_aperture()         { return get_property("CAM_LENS_APERTURE"); }
			std::string	camera_model()                 { return get_property("CAM"); }
			std::string	camera_white_balance_mode()    { return get_property("CAM_WHITE_BALANCE_MODE"); }
			std::string	device_temperature()           { return get_property("HK_T_DEV"); }
			std::string	error_count()                  { return get_property("ERR_COUNT"); }
			std::string	gps_mode()                     { return get_property("GPS_MODE"); }
			std::string	gps_status()                   { return get_property("GPS_STATUS"); }
			std::string	gps_top_supply_voltage()       { return get_property("GPS_EXT_SUPPLY_VOLTAGE"); }
			std::string	height_above_msl()             { return get_property("ATMOS_AMSL"); }
			std::string	instrument_identifier()        { return get_property("INST_IDENT"); }
			std::string	laser_prr()                    { return get_property("LASER_PRR"); }
			std::string	laser_prr_measured()           { return get_property("LASER_PRR_MEAS"); }
			std::string	lines_per_second()             { return get_property("SCN_LINES_PER_SEC"); }
			std::string	measurement_program()          { return get_property("MEAS_PROG_STATUS"); }
			std::string	measurement_status()           { return get_property("MEAS_STATUS"); }
			std::string	near_range_enabled()           { return get_property("FILT_NEAR_RNG_ACTIVE"); }
			std::string	phi_current_angle()            { return get_property("SCN_PHI_SOCS"); }
			std::string	phi_increment()                { return get_property("SCN_PHI_SOCS_INCR"); }
			std::string	phi_speed()                    { return get_property("SCN_FRAME_SPEED"); }
			std::string	phi_start_angle()              { return get_property("SCN_PHI_SOCS_START"); }
			std::string	phi_stop_angle()               { return get_property("SCN_PHI_SOCS_STOP"); }
			std::string	power_supply()                 { return get_property("HK_U_IN_SEL"); }
			std::string	reduced_quality_enabled()      { return get_property("FILT_REDUCED_QUALITY_ENABLE"); }
			std::string	requested_number_scans()       { return get_property("SCN_SET_NUM_SCANS"); }
			std::string	requested_phi_increment()      { return get_property("SCN_SET_PHI_SOCS_INCR"); }
			std::string	requested_phi_start_angle()    { return get_property("SCN_SET_PHI_SOCS_START"); }
			std::string	requested_phi_stop_angle()     { return get_property("SCN_SET_PHI_SOCS_STOP"); }
			std::string	requested_theta_increment()    { return get_property("SCN_SET_THETA_SOCS_INCR"); }
			std::string	requested_theta_start_angle()  { return get_property("SCN_SET_THETA_SOCS_START"); }
			std::string	requested_theta_stop_angle()   { return get_property("SCN_SET_THETA_SOCS_STOP"); }
			std::string	scan_estimated_duration()      { return get_property("SCN_TCALC"); }
			std::string	scan_progress()                { return get_property("SCN_PROGRESS"); }
			std::string	scan_time_elapsed()            { return get_property("SCN_TELAPS"); }
			std::string	scanner_date()                 { return get_property("DATE"); }
			std::string	scanner_time()                 { return get_property("TIME"); }
			std::string	supplied_voltage()             { return get_property("HK_U_IN"); }
			std::string	supplied_voltage_1()           { return get_property("HK_U_IN1"); }
			std::string	supplied_voltage_2()           { return get_property("HK_U_IN2"); }
			std::string	theta_increment()              { return get_property("SCN_THETA_SOCS_INCR"); }
			std::string	theta_park_angle()             { return get_property("SCN_THETA_SOCS_PARK"); }
			std::string	theta_speed()                  { return get_property("SCN_LINE_SPEED"); }
			std::string	theta_start_angle()            { return get_property("SCN_THETA_SOCS_START"); }
			std::string	theta_stop_angle()             { return get_property("SCN_THETA_SOCS_STOP"); }


			// Setters
			void	set_file_identifier(std::string identifier);
			void	set_log_file_dump(std::string filename);
			void	set_logging_enabled(bool logging_enabled);
			void	set_output_directory(std::string fullpath);

			// Getters
			bool    is_connected() const { return is_connected_; }

			std::string datestring()       const { return date_string_; }
			std::string file_identifier()  const { return file_identifier_; }
			std::string ip_address()       const { return ip_address_; }
			std::string log_file_dump()    const { return log_file_dump_; }
			std::string log_file_scan()    const { return log_file_scan_; }
			std::string output_directory() const { return output_directory_; }
			ScanType    scan_type()        const { return scan_type_; }


		protected:

			/** Member Variables **/
			bool	is_connected_;			// Connected to scanner
			bool	is_logging_enabled_;	// Per-scan logging enabled

			std::string	file_identifier_;	// Optional string to be included in filenames
			std::string	ip_address_;		// The IP address of the scanner
			std::string	log_file_dump_;		// Log file for scanner dump
			std::string	log_file_scan_;
			std::string	output_directory_;	// Directory to contain scan data

			VerboseLevel	verbose_level_;	// Level of verbosity at command-line


			/** Member Functions **/
			void	error(std::string error_string);
			void	status(std::string status_string_1, std::string status_string_2 = "", std::string status_string_3 = "");
			void	warn(std::string warning_string);


		private:

			/** Member Variables **/
			ctrllib::ctrl_client_session	scanner;	// The scanner control session

			// Log file
			std::vector<std::string> log_buffer_;
			std::ofstream            log_scan_;

			// Scan specific information
			std::string	date_string_;
			float		line_time_;
			ScanType	scan_type_;


			/** Member Functions **/
			void                     build_datestring();
			std::string              build_filename(ScanType type, std::string extension);
			std::string              execute_command(std::string cmd, std::string args = "");
			std::vector<std::string> execute_command_comments(std::string cmd, std::string args = "");
			std::string              execute_command_silent(std::string cmd, std::string args = "");
			std::string              get_property(std::string property);
			void                     log(std::string col1, std::string col2, std::string col3, bool exclude = false);
			void                     open_log_file_scan(bool force = false);
			void                     set_property(std::string property, std::string value);

	};

}


#endif // VZ1000_H
