#ifndef FRF_GLOBALS_H
#define FRF_GLOBALS_H


/** Colors for command-line output on linux machines **/
#ifndef _WIN32
#define RED "\e[1;31m"
#define GREEN "\e[1;32m"
#define YELLOW "\e[1;33m"
#define BLUE "\e[1;34m"
#define CYAN "\e[1;36m"
#define NORMAL "\e[0m"
#endif

/** Widths of various columns for command-line and file output **/
#define CMD_WIDTH_1 15		// Command line, first column - typically the output category
#define CMD_WIDTH_2 30		// Command line, second column - typically output message
#define LOG_WIDTH_1 15		// Log file, first column - typically the command issued
#define LOG_WIDTH_2 30		// Log file, second column - typically the property name
#define STATUS_WIDTH 25		// Status/warnings file, all column widths (except last, which fits data)

#endif
