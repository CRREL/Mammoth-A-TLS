#ifndef INPUT_PARSER_H
#define INPUT_PARSER_H

#include "../globals.h"
#include "../scanners/VZ1000.h"

#include <iostream>
#include <sstream>
#include <string.h>
#include <vector>

namespace frf {

	class InputParser {

		public:

			InputParser();
			~InputParser();

			VZ1000*	build_scanner(int argc, char** argv);

			bool		log_status() const { return log_status_; }
			bool		log_warnings() const { return log_warnings_; }
			std::string	output_directory() const { return output_directory_; }
			std::string	status_file() const { return status_file_; }
			std::string	warnings_file() const { return warnings_file_; }

		protected:

			std::vector<std::vector<std::string> >	options;

			bool		log_status_;
			bool		log_warnings_;
			std::string	output_directory_;
			VZ1000*		scanner;
			std::string	status_file_;
			std::string	warnings_file_;

			int		get_option_index(std::string option);
			bool	load_framescan(int index);
			bool	load_framescan_seq(int index);
			bool	load_linescan(int index);
			bool	parse_options(int argc, char** argv);
			void	usage();

			void	missing(std::string option);
			void	unknown(std::string option);
			void	warn(std::string warning);
			void	wrong_number_args(std::string option);

	};

}

#endif
