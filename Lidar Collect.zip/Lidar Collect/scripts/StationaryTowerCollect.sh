#!/bin/bash

(

	# Collection executable
	COLLECT_EXE=/home/tristan/pier/LidarCollect/build/LidarCollect
	
	# Directories
	DATA_DIR=/home/tristan/pier/data/LidarCollect/     # Local storage directory
	RAID_DIR=/media/tristan/kahuna/Realtime_dune_lidar/Raw/
	RAID_SCANNER_STATUS=/media/tristan/kahuna/Realtime_dune_lidar/scanner-status.txt
	RAID_SCANNER_ERRORS=/media/tristan/kahuna/Realtime_dune_lidar/scanner-errors.txt
	WEB_SCANNER_STATUS=/media/tristan/kahuna/Realtime_dune_lidar/Web/scanner-status.txt
	WEB_SCANNER_ERRORS=/media/tristan/kahuna/Realtime_dune_lidar/Web/scanner-errors.txt

	# Scanner variables
	SCANNER_IP=192.168.0.13
	STATUS_FILE=$DATA_DIR/scanner-status.txt
	ERROR_FILE=$DATA_DIR/scanner-errors.txt

	# Email status variables
	USE_EMAIL=true
	EMAIL_DIR=/mnt/gaia/gages/daqMonitor/daqMails/

	# Get the current datestring and create a folder for this
	# scan session's data
	DATE_STR=`date +%Y%m%d-%H%M-%S`
	OUT_DIR=$DATA_DIR/$DATE_STR.FRFNProp
	mkdir $OUT_DIR

	# Make sure directory created successfully before continuing
	if [ -d "$OUT_DIR" ]; then
	
		# We're going to be storing all command-line output to a text file
		CMD_FILE=$OUT_DIR/commands.txt
		
		# First make sure the scanner is on the network
		if ! ping -c 1 $SCANNER_IP &> /dev/null; then
			echo "Unable to find scanner at ${SCANNER_IP}" | tee -a $CMD_FILE
			if [ "$USE_EMAIL" = true ] && [ -d "$EMAIL_DIR"]; then
				cp error-mails/lidar-no-ping.msg $EMAIL_DIR
			fi
			exit 1
		fi
		
		# Obtain an exclusive lock, so if the scanner takes too long or gets
		# hung up, we won't try to run the next scan
		if flock -x -n 200; then
		
			# Peform scans
			$COLLECT_EXE --ip $SCANNER_IP --line 0 30 130 0.025 180.2 1800 FRFNProp --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE | tee -a $CMD_FILE
			sleep 10
			$COLLECT_EXE --ip $SCANNER_IP --frame 0 63 130 0.01 256 302 0.05 FRFNProp --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE | tee -a $CMD_FILE
			sleep 10
			$COLLECT_EXE --ip $SCANNER_IP --frame 0 30 130 0.04 125 259 0.04 FRFNProp --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE | tee -a $CMD_FILE
			sleep 10
			$COLLECT_EXE --ip $SCANNER_IP --frame 0 37 130 0.01 65 128 0.05 FRFNProp --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE | tee -a $CMD_FILE
			
			# Release exclusive lock
			flock -u 200
			
			# Are we mounted and able to see the RAID?
			if [ -d "$RAID_DIR" ]; then
			
				# Overwrite the status files on the RAID
				cp $STATUS_FILE $RAID_SCANNER_STATUS
				cp $ERROR_FILE $RAID_SCANNER_ERRORS
				
				# Overwrite the status files in the web directory
				cp $STATUS_FILE $WEB_SCANNER_STATUS
				cp $ERROR_FILE $WEB_SCANNER_ERRORS
			
				# Try to copy the entire directory to the RAID
				if cp -r $OUT_DIR $RAID_DIR; then
					
					# If files were successfully copied, delete them from the collect computer
					rm -r $OUT_DIR
					
				fi
				
			else
				echo "RAID not mounted or inaccessible, leaving data on collect computer" | tee -a $CMD_FILE
				if [ "$USE_EMAIL" = true ] && [ -d "$EMAIL_DIR"]; then
					cp error-mails/lidar-no-raid.msg $EMAIL_DIR
				fi
			fi
		
		else
			echo "Unable to obtain lock. Scanner may already be in use." | tee -a $CMD_FILE
			if [ "$USE_EMAIL" = true ] && [ -d "$EMAIL_DIR"]; then
				cp error-mails/lidar-no-lock.msg $EMAIL_DIR
			fi
			exit 1
		fi
	
	else
		echo -e "\e[1;31mUnable to create scan directory ${OUT_DIR}\e[0m"
		if [ "$USE_EMAIL" = true ] && [ -d "$EMAIL_DIR"]; then
			cp error-mails/lidar-no-dir.msg $EMAIL_DIR
		fi
		exit 1
	fi
	
) 200>/var/lock/.LidarCollect.exclusivelock
