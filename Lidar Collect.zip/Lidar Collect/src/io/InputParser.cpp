#include "../../include/io/InputParser.h"

namespace frf {

	InputParser::InputParser()
	{
		log_status_ = false;
		log_warnings_ = false;
		scanner = 0;
		status_file_ = "scanner-status.txt";
		warnings_file_ = "scanner-warnings.txt";
	}

	InputParser::~InputParser()
	{
		if (scanner) {
			delete scanner;
		}
	}

	VZ1000 *InputParser::build_scanner(int argc, char** argv)
	{
		// Parse command-line inputs
		if (!parse_options(argc, argv)) {
			usage();
			return 0;
		}

		// Find the ip address
		int ip_index = get_option_index("--ip");
		if (ip_index == -1) {
			missing("--ip");
			return 0;
		}

		// Find the level of verbose output
		VZ1000::VerboseLevel verbose = VZ1000::VERBOSE;
		for (int i=0; i<options.size(); ++i) {
			if (options[i][0] == "--silent") verbose = VZ1000::SILENT;
			if (options[i][0] == "--quiet") verbose = VZ1000::QUIET;
			if (options[i][0] == "--verbose") verbose = VZ1000::VERBOSE;
			if (options[i][0] == "--loud") verbose = VZ1000::LOUD;
		}

		// Create the scanner
		scanner = new VZ1000(options[ip_index][1], verbose);

		// Check for output directory
		int dir_index = get_option_index("--dir");
		if (dir_index != -1) {
			if (options[dir_index].size() == 2) {
				scanner->set_output_directory(options[dir_index][1]);
				output_directory_ = options[dir_index][1] + '/';
			} else {
				wrong_number_args("--dir");
				return 0;
			}
		}

		// Check for per-scan logging
		int log_index = get_option_index("--log");
		if (log_index != -1) {
			scanner->set_logging_enabled(true);
		}

		// Check for dump logfile
		int dump_index = get_option_index("--dump");
		if (dump_index != -1) {
			if (options[dump_index].size() == 2)
				scanner->set_log_file_dump(options[dump_index][1]);
			else {
				wrong_number_args("--dump");
				return 0;
			}
		}

		// Check for scanner status file
		int status_index = get_option_index("--status");
		if (status_index != -1) {
			log_status_ = true;
			if (options[status_index].size() == 2)
				status_file_ = options[status_index][1];
		}

		// Check for scanner warnings file
		int warnings_index = get_option_index("--warnings");
		if (warnings_index != -1) {
			log_warnings_ = true;
			if (options[warnings_index].size() == 2)
				warnings_file_ = options[warnings_index][1];
		}

		// Check for humidity
		int humidity_index = get_option_index("--humidity");
		if (humidity_index != -1) {
			if (options[humidity_index].size() == 2)
				scanner->set_atmospheric_humidity(std::stoi(options[humidity_index][1]));
			else {
				wrong_number_args("--humidity");
				return 0;
			}
		}

		// Check for pressure
		int pressure_index = get_option_index("--pressure");
		if (pressure_index != -1) {
			if (options[pressure_index].size() == 2)
				scanner->set_atmospheric_pressure_sl(std::stoi(options[pressure_index][1]));
			else {
				wrong_number_args("--pressure");
				return 0;
			}
		}

		// Check for temperature
		int temperature_index = get_option_index("--temperature");
		if (temperature_index != -1) {
			if (options[temperature_index].size() == 2)
				scanner->set_atmospheric_temperature(std::stoi(options[temperature_index][1]));
			else {
				wrong_number_args("--temperature");
				return 0;
			}
		}

		// Check for camera exposure mode
		int exposure_index = get_option_index("--exposure_mode");
		if (exposure_index != -1) {
			if (options[exposure_index].size() == 2)
				scanner->set_camera_exposure_mode(std::stoi(options[exposure_index][1]));
			else {
				wrong_number_args("--exposure_mode");
				return 0;
			}
		}

		// Check for camera exposure time
		int time_index = get_option_index("--exposure_time");
		if (time_index != -1) {
			if (options[time_index].size() == 2)
				scanner->set_camera_exposure_time(std::stof(options[time_index][1]));
			else {
				wrong_number_args("--exposure_time");
				return 0;
			}
		}

		// Check for camera exposure time
		int lens_index = get_option_index("--lens_aperture");
		if (lens_index != -1) {
			if (options[lens_index].size() == 2)
				scanner->set_camera_lens_aperture(std::stof(options[lens_index][1]));
			else {
				wrong_number_args("--lens_aperture");
				return 0;
			}
		}

		// Check for camera white balance
		int wb_index = get_option_index("--white_balance");
		if (wb_index != -1) {
			if (options[wb_index].size() == 2)
				scanner->set_camera_white_balance_mode(std::stoi(options[wb_index][1]));
			else {
				wrong_number_args("--white_balance");
				return 0;
			}
		}

		// Check for gps mode
		int gps_index = get_option_index("--gps");
		if (gps_index != -1) {
			if (options[gps_index].size() == 2)
				scanner->set_gps_mode(std::stoi(options[gps_index][1]));
			else {
				wrong_number_args("--gps");
				return 0;
			}
		}

		// Check for gps voltage
		int gpsv_index = get_option_index("--gps_voltage");
		if (gpsv_index != -1) {
			if (options[gpsv_index].size() == 2)
				scanner->set_gps_mode(std::stof(options[gpsv_index][1]));
			else {
				wrong_number_args("--gps_voltage");
				return 0;
			}
		}

		// Check for near range enabled
		int near_index = get_option_index("--near_range_enabled");
		if (near_index != -1) {
			if (options[near_index].size() == 2)
				scanner->set_near_range_enabled(options[near_index][1] == "true" ? true : false);
			else {
				wrong_number_args("--near_range_enabled");
				return 0;
			}
		}

		// Check for reduced quality enabled
		int quality_index = get_option_index("--reduced_quality_enabled");
		if (quality_index != -1) {
			if (options[quality_index].size() == 2)
				scanner->set_reduced_quality_enabled(options[quality_index][1] == "true" ? true : false);
			else {
				wrong_number_args("--reduced_quality_enabled");
				return 0;
			}
		}

		// Find scan type
		for (int i=0; i<options.size(); ++i) {

			if (options[i][0] == "--line") {
				if (!load_linescan(i))
					return 0;
			}

			if (options[i][0] == "--frame") {
				if (!load_framescan(i))
					return 0;
			}

			if (options[i][0] == "--frameseq") {
				if (!load_framescan_seq(i))
					return 0;
			}
		}

		return scanner;
	}


	int InputParser::get_option_index(std::string option)
	{
		for (int i=0; i<options.size(); ++i) {
			if (options[i][0] == option) {
				return i;
			}
		}
		return -1;
	}


	bool InputParser::load_framescan(int index)
	{
		if (options[index].size() == 8 || options[index].size() == 9) {

			try {

				// Parse inputs
				int measurement_program = std::stoi(options[index][1]);
				float theta_start = std::stof(options[index][2]);
				float theta_end = std::stof(options[index][3]);
				float theta_increment = std::stof(options[index][4]);
				float phi_start = std::stof(options[index][5]);
				float phi_end = std::stof(options[index][6]);
				float phi_increment = std::stof(options[index][7]);

				// Set the measurement program
				scanner->framescan(measurement_program,
								   theta_start, theta_end, theta_increment,
								   phi_start, phi_end, phi_increment);

				// Check for the file identifier
				if (options[index].size() == 9)
					scanner->set_file_identifier(options[index][8]);

			}

			catch (std::exception& e) {

				warn(std::string("Framescan error: ") + e.what());
				return false;

			}
		}

		else {
			wrong_number_args("--frame");
			return false;
		}

		return true;
	}


	bool InputParser::load_framescan_seq(int index)
	{
		if (options[index].size() == 9 || options[index].size() == 10) {

			try {

				// Parse inputs
				int measurement_program = std::stoi(options[index][1]);
				float theta_start = std::stof(options[index][2]);
				float theta_end = std::stof(options[index][3]);
				float theta_increment = std::stof(options[index][4]);
				float phi_start = std::stof(options[index][5]);
				float phi_end = std::stof(options[index][6]);
				float phi_increment = std::stof(options[index][7]);
				int numscans = std::stoi(options[index][8]);

				// Set the measurement program
				scanner->framescan(measurement_program,
								   theta_start, theta_end, theta_increment,
								   phi_start, phi_end, phi_increment,
								   numscans);

				// Check for the file identifier
				if (options[index].size() == 10)
					scanner->set_file_identifier(options[index][9]);

			}

			catch (std::exception& e) {

				warn(std::string("Framescan error: ") + e.what());
				return false;

			}
		}

		else {
			wrong_number_args("--frameseq");
			return false;
		}

		return true;
	}


	bool InputParser::load_linescan(int index)
	{
		// Check for correct number of arguments
		if (options[index].size() == 7 || options[index].size() == 8) {

			try {

				// Parse inputs
				int measurement_program = std::stoi(options[index][1]);
				float theta_start = std::stof(options[index][2]);
				float theta_end = std::stof(options[index][3]);
				float theta_increment = std::stof(options[index][4]);
				float phi = std::stof(options[index][5]);
				float duration = std::stof(options[index][6]);

				// Set the measurement program
				scanner->linescan(measurement_program, theta_start, theta_end,
								  theta_increment, phi, duration);

				// Check for file identifier
				if (options[index].size() == 8)
					scanner->set_file_identifier(options[index][7]);

			}

			catch (std::exception& e) {

				warn(std::string("Linescan error: ") + e.what());
				return false;

			}

		} else {

			wrong_number_args("--line");
			return false;

		}

		return true;
	}


	bool InputParser::parse_options(int argc, char **argv)
	{
		/** Each feature begins with two dashes (--), so package each
		 *  flag with the set of input options provided after the flag
		 *  and maintain the input order **/

		std::vector<std::string> curroption;
		bool inoption = false;

		for (int i=1; i<argc; ++i)
		{
			if (strlen(argv[i]) > 1)
			{
				if (argv[i][0] == '-' && argv[i][1] == '-' && curroption.size() > 0)
				{
					options.push_back(curroption);
					curroption.clear();
				}

				curroption.push_back(argv[i]);
				inoption = true;
			}

			else if (inoption)
			{
				curroption.push_back(argv[i]);
			}

			if (i + 1 == argc)
			{
				options.push_back(curroption);
			}
		}

		return true;
	}


	void InputParser::usage()
	{
#ifndef _WIN32
		std::cout << GREEN;
#endif
		std::cout << "-------------------" << std::endl;
		std::cout << "-- Lidar Collect --" << std::endl;
		std::cout << "-------------------" << std::endl;
		std::cout << "See https://github.com/FRF-Remote-Sensing/LidarCollect/wiki for usage instructions" << std::endl << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}


	void InputParser::missing(std::string option)
	{
		usage();
#ifndef _WIN32
		std::cout << BLUE;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << "[INPUT]";
#ifndef _WIN32
		std::cout << RED;
#endif
		std::cout << "Missing required option: " << option << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}


	void InputParser::unknown(std::string option)
	{
#ifndef _WIN32
		std::cout << BLUE;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << "[INPUT]";
#ifndef _WIN32
		std::cout << YELLOW;
#endif
		std::cout << "Unknown argument with option: " << option << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}


	void InputParser::warn(std::string warning)
	{
#ifndef _WIN32
		std::cout << BLUE;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << "[INPUT]";
#ifndef _WIN32
		std::cout << YELLOW;
#endif
		std::cout << warning << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}


	void InputParser::wrong_number_args(std::string option)
	{
#ifndef _WIN32
		std::cout << BLUE;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << "[INPUT]";
#ifndef _WIN32
		std::cout << RED;
#endif
		std::cout << "Wrong number of arguments with: " << option << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}
}
